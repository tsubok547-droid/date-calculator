// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'history_filter_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$historyFilterNotifierHash() =>
    r'f562f9e2378f3e0ef6d627e34be1a6e28293cff1';

/// See also [HistoryFilterNotifier].
@ProviderFor(HistoryFilterNotifier)
final historyFilterNotifierProvider =
    AutoDisposeNotifierProvider<
      HistoryFilterNotifier,
      HistoryFilterState
    >.internal(
      HistoryFilterNotifier.new,
      name: r'historyFilterNotifierProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$historyFilterNotifierHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$HistoryFilterNotifier = AutoDisposeNotifier<HistoryFilterState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
