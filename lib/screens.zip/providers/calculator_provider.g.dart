// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'calculator_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$calculatorNotifierHash() =>
    r'236c5e82e473d130dc07c928d6c7c37c3544dbfc';

/// See also [CalculatorNotifier].
@ProviderFor(CalculatorNotifier)
final calculatorNotifierProvider =
    AutoDisposeNotifierProvider<CalculatorNotifier, CalculationState>.internal(
      CalculatorNotifier.new,
      name: r'calculatorNotifierProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$calculatorNotifierHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$CalculatorNotifier = AutoDisposeNotifier<CalculationState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
