// lib/utils/constants.dart

class PrefKeys {
  static const String primaryColor = 'primaryColor';
  static const String isJapaneseCalendar = 'isJapaneseCalendar';
  static const String calcHistory = 'calcHistory';
}